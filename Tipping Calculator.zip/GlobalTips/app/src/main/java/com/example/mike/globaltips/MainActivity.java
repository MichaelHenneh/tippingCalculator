package com.example.mike.globaltips;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.app.ExpandableListActivity;
import android.content.Context;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.view.LayoutInflater;
import android.app.ExpandableListActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.ExpandableListView;
import java.util.ArrayList;


public class MainActivity extends Activity implements OnClickListener{
    EditText bill, tip, billDividedByNo;
    Button submit, divide;
    TextView outputWithout, outputGroupTip, outputGroupedTotal, outputDividedTotal, outputTipDivided,roundValueUp, roundValueDown, roundTipUp, roundTipDown;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submit = (Button) findViewById(R.id.submit);
        submit.setOnClickListener(this);
        divide = (Button) findViewById(R.id.divide);
        divide.setOnClickListener(this);
        bill = (EditText) findViewById(R.id.val1);
        tip = (EditText) findViewById(R.id.val2);
        billDividedByNo = (EditText) findViewById(R.id.divisor);
        roundValueUp = (TextView) findViewById(R.id.billRoundUpValue);
        roundValueDown = (TextView) findViewById(R.id.billDownValue);
        roundTipUp = (TextView) findViewById(R.id.billRoundUpTip);
        roundTipDown = (TextView) findViewById(R.id.billRoundDownTip);
        outputWithout = (TextView) findViewById(R.id.outputOriginalBill);
        outputGroupTip = (TextView) findViewById(R.id.outputTip);
        outputGroupedTotal = (TextView) findViewById(R.id.outputTotalGroupedBill);
        outputDividedTotal = (TextView) findViewById(R.id.outputBillMulti);
        outputTipDivided = (TextView) findViewById(R.id.outputTipDivided);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onClick(View v) {

        float totalBill = Float.parseFloat(bill.getText().toString());
        float tipValue = Float.parseFloat(tip.getText().toString());

        switch (v.getId()) {
            case R.id.submit:

                //calculating tip percentage
                float tipPercentage = ((tipValue / 100) *totalBill);
                //calculating final bill
                float finalBill = totalBill +tipPercentage;

                //set original bill, new final bill and tip to two decimal place
                String totalBillText = String.format("%.2f", totalBill);
                String finalBillText = String.format("%.2f", finalBill);
                String tipAmountResult = String.format("%.2f", tipPercentage);

                //output original bill, new bill with tip and value of tip
                outputWithout.setText(totalBillText);
                outputGroupedTotal.setText(finalBillText);
                outputGroupTip.setText(tipAmountResult);

                //round up total of final bill and tip
                roundValueUp.setText(Double.toString(Math.ceil(finalBill)));
                roundTipUp.setText(Double.toString(Math.ceil(tipPercentage)));

                //round down total of final bill and tip
                roundValueDown.setText(Double.toString(Math.floor(finalBill)));
                roundTipDown.setText(Double.toString(Math.floor(tipPercentage)));

                break;

            case R.id.divide:
                float numberDivisor = Float.parseFloat(billDividedByNo.getText().toString());

                //to ensure bill divisor is greater than 0
                if (Float.parseFloat(tip.getText().toString())>0){

                    //the division of the final bill and tip by number of split
                    float totalBillToSplit = ((tipValue/100) *totalBill) /numberDivisor;
                    float tipBillDivided = totalBillToSplit /numberDivisor;

                    //set divided bill to two decimal place
                    String outputDividedTotalString = String.format("%.2f",totalBillToSplit);
                    outputDividedTotal.setText(outputDividedTotalString);

                    //set divided tip to two decimal place
                    String outputDividedTipString = String.format("%.2f",tipBillDivided);
                    outputTipDivided.setText(outputDividedTipString);

                    break;

                } else {
                    displayToastAlt();
                }

        }
    }

    public void displayToastAlt() {
        Toast.makeText(this,"Please Make Tip Greater Than Zero.",Toast.LENGTH_LONG).show();
    }

}

